// API helper placeholder
export async function fetcher(url){ const res = await fetch(url); if(!res.ok) throw new Error('API error'); return res.json(); }
