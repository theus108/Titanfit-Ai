// Auth service placeholder
export function isAdmin(){ return true; }
