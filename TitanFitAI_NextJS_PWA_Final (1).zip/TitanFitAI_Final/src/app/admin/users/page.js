\ 
export default function Page(){
  return (
    <div style={padding:20,color:'#fff'}> 
      <h2>Users</h2>
      <p style={color:'#aaa'}>Seção users do painel — dados de exemplo.</p>
    </div>
  )
}
