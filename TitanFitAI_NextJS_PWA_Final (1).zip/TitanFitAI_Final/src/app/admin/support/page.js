\ 
export default function Page(){
  return (
    <div style={padding:20,color:'#fff'}> 
      <h2>Support</h2>
      <p style={color:'#aaa'}>Seção support do painel — dados de exemplo.</p>
    </div>
  )
}
