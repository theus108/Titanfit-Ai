\ 
export default function Page(){
  return (
    <div style={padding:20,color:'#fff'}> 
      <h2>Finance</h2>
      <p style={color:'#aaa'}>Seção finance do painel — dados de exemplo.</p>
    </div>
  )
}
