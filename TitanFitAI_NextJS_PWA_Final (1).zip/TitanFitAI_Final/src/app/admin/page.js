import Link from 'next/link';

export default function AdminPage(){
  return (
    <main style={{minHeight:'100vh', padding:20, background:'#070707', color:'#fff'}}>
      <div style={{maxWidth:1000, margin:'0 auto'}}>
        <h1>TitanFit AI — Painel Admin</h1>
        <p style={{color:'#aaa'}}>Painel administrativo responsivo. Acesse as seções abaixo.</p>
        <nav style={{display:'flex', gap:12, marginTop:20}}>
          <Link href='/admin/users'><button style={{padding:10}}>Usuários</button></Link>
          <Link href='/admin/finance'><button style={{padding:10}}>Financeiro</button></Link>
          <Link href='/admin/support'><button style={{padding:10}}>Suporte</button></Link>
          <Link href='/'><button style={{padding:10}}>Voltar ao App</button></Link>
        </nav>
      </div>
    </main>
  )
}
