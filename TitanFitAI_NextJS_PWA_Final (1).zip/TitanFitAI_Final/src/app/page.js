export default function Home() {
  return (
    <main style={{background:'#000', color:'#fff', minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column'}}>
      <h1 style={{fontSize:36}}>TitanFit AI</h1>
      <p style={{color:'#ccc', maxWidth:700, textAlign:'center'}}>Treino. Nutrição. Transformação. IA 24h. Tudo em um único app.</p>
      <div style={{display:'flex', gap:12, marginTop:20}}>
        <button style={{padding:'12px 20px', borderRadius:12, background:'#6C5CE7', color:'#fff', border:'none'}}>Começar Agora (7 dias grátis)</button>
        <a href='/admin' style={{padding:'12px 20px', borderRadius:12, background:'#222', color:'#fff', textDecoration:'none', display:'inline-block'}}>Painel Admin</a>
      </div>
    </main>
  );
}
